rpm = 1000
from tkinter import*
from tkinter import messagebox
root = Tk()
root.title('CAR')
root.geometry('400x300')
root.config(bg='white')

l1 = Label(root, text=rpm, font=30)
l1.pack()


def f():
    global rpm
    rpm = 1000


def accelerate():
    global rpm
    rpm += 100
    l1.config(text=rpm)
    if rpm > 1500:
            import winsound
            winsound.Beep(2000, 2000)
            messagebox.showinfo(title = 'Warning', message = 'warning RPM too high')


def brake():
    global rpm
    rpm -= 100
    l1.config(text=rpm)
    print(rpm)
    if rpm > 1500:
            import winsound
            winsound.Beep(1000, 1000)
            messagebox.showinfo(title='Warning', message='warning RPM too high')

Button(root, text = 'Accelerate', font = 20, command=accelerate).place(x=200, y=90)
Button(root, text = 'Brake', font =20, command=brake).place(x=50, y=90)

root.mainloop()